var a='world';
alert('hello '+a);
